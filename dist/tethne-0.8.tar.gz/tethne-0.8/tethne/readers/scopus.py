"""
Reader for Scopus bibliographic database.

Earlier versions of Tethne had limited support for Scopus. As of 0.8, we've
moved away from Scopus due to (a) lack of access, and (b) lack of time. If
you're interested in using Scopus data in Tethne, please consider contributing
to the project.
"""
