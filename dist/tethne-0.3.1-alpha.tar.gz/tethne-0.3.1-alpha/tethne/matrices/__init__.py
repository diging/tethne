"""
Methods for generating matrices from :class:`.Paper` objects and other data.

.. autosummary::

   dfr

"""

import tethne.matrices.dfr