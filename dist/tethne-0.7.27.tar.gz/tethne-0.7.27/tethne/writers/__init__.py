"""
Export networks to structured and unstructured formats, for visualization.

.. autosummary::

   collection
   graph
   corpora
   matrix
   
"""

