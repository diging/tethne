"""
Methods for writing matrices to commonly-used file formats, for external
visualization and analysis. Not yet implemented.
"""
