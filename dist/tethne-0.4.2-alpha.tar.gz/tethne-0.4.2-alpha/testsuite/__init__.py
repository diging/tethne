"""
Tethne test suite
"""
