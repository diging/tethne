"""
Reader for the DuraSpace API.

This module is not yet implemented. Earlier versions of Tethne had a crude
method for reading data from an old REST API. The current version of DuraSpace
has a very different API, and we ought to write a much better client.

Stay tuned! 
"""
